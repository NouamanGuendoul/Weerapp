package com.example.gurnick;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Haal invoervelden en knop op uit de layout
        EditText usernameInput = findViewById(R.id.username);
        EditText passwordInput = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.loginButton);

        // Stel een OnClickListener in voor de login-knop
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Simpele validatie voor testlogin
            if (username.equals("admin") && password.equals("password")) {
                // Inloggegevens correct, ga naar MainActivity2
                Toast.makeText(this, "Login succesvol!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, MainActivity2.class);
                startActivity(intent);
                finish(); // Sluit LoginActivity zodat de gebruiker niet terug kan gaan
            } else {
                // Inloggegevens onjuist
                Toast.makeText(this, "Ongeldige gebruikersnaam of wachtwoord", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
