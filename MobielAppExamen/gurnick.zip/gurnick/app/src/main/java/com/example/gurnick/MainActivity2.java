package com.example.gurnick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity2 extends AppCompatActivity {

    // Voeg jouw WeatherAPI-sleutel hier toe
    public static final String API_KEY = "b77ae18de12a4a0ab00144539242012";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText cityInput = findViewById(R.id.cityInput);
        Button fetchWeatherButton = findViewById(R.id.fetchWeatherButton);
        TextView weatherOutput = findViewById(R.id.weatherOutput);

        fetchWeatherButton.setOnClickListener(v -> {
            String cityName = cityInput.getText().toString();
            fetchWeatherData(cityName, weatherOutput);
        });
    }

    private void fetchWeatherData(String city, TextView weatherOutput) {
        new Thread(() -> {
            try {
                // Stel de URL in voor WeatherAPI
                String apiUrl = "https://api.weatherapi.com/v1/current.json?key=" + API_KEY + "&q=" + city + "&aqi=no";
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();

                // Controleer of de respons succesvol is (statuscode 200)
                if (connection.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    // Parse de JSON-respons
                    JSONObject weatherData = new JSONObject(response.toString());
                    JSONObject current = weatherData.getJSONObject("current");
                    String temperature = current.getString("temp_c"); // Temperatuur in Celsius
                    String description = current.getJSONObject("condition").getString("text"); // Beschrijving van het weer

                    // Update de UI met de weerinformatie
                    runOnUiThread(() -> weatherOutput.setText("Temperatuur: " + temperature + "°C\nBeschrijving: " + description));
                } else {
                    // Toon een foutmelding als de respons niet succesvol is
                    runOnUiThread(() -> weatherOutput.setText("Fout: Kan gegevens niet ophalen. Controleer de stad of API-sleutel."));
                }
            } catch (Exception e) {
                // Algemene foutafhandeling
                e.printStackTrace();
                runOnUiThread(() -> weatherOutput.setText("Fout bij het ophalen van gegevens!"));
            }
        }).start();
    }
}
